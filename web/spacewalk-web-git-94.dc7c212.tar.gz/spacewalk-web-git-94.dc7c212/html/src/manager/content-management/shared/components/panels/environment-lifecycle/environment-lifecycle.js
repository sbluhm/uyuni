// @flow
import React from 'react';
import CreatorPanel from "../../../../../../components/panels/CreatorPanel";
import EnvironmentView from "./environment-view";
import EnvironmentForm from "./environment-form";
import {Loading} from "components/utils/Loading";
import Promote from "../promote/promote";
import {showErrorToastr, showSuccessToastr} from "components/toastr/toastr";
import {mapAddEnvironmentRequest, mapUpdateEnvironmentRequest} from './environment.utils';

import useRoles from "core/auth/use-roles";
import {isOrgAdmin} from "core/auth/auth.utils";
import useLifecycleActionsApi from "../../../api/use-lifecycle-actions-api";
import getRenderedMessages from "../../messages/messages";

import type {ProjectEnvironmentType, ProjectHistoryEntry, ProjectMessageType}
  from "../../../type/project.type";

type Props = {
  projectId: string,
  environments: Array<ProjectEnvironmentType>,
  historyEntries: Array<ProjectHistoryEntry>,
  onChange: Function,
  messages?: Array<ProjectMessageType>
};

const EnvironmentLifecycle = (props: Props) => {

  const {onAction, cancelAction, isLoading} = useLifecycleActionsApi({
    resource: 'projects', nestedResource:"environments"
  });
  const roles = useRoles();
  const hasEditingPermissions = isOrgAdmin(roles);

  const messages = getRenderedMessages(props.messages || []);

  return (
    <CreatorPanel
      id="environmentLifecycle"
      title={t("Environment Lifecycle")}
      creatingText={t("Add Environment")}
      className={messages.panelClass}
      panelLevel="2"
      disableEditing={!hasEditingPermissions}
      collapsible
      customIconClass="fa-small"
      disableOperations={isLoading}
      onSave={({ item, closeDialog }) =>
        onAction(mapAddEnvironmentRequest(item, props.environments, props.projectId), "create", props.projectId)
          .then((projectWithCreatedEnvironment) => {
            closeDialog();
            showSuccessToastr(t("Environment created successfully"));
            props.onChange(projectWithCreatedEnvironment)
          })
          .catch((error) => {
            showErrorToastr(error, {autoHide: false});
          })}
      onOpen={({ setItem }) => setItem({})}
      onCancel={() => cancelAction()}
      renderCreationContent={({ open, item, setItem }) => {

        if (!open) {
          return null;
        }

        if (isLoading) {
          return (
            <Loading text={t('Creating the environment...')}/>
          )
        }

        return (
          <EnvironmentForm
            environment={{...item}}
            environments={props.environments}
            onChange={(item) => setItem(item)}/>
        )
      }}
      renderContent={() =>
        <div className="min-height-panel">
          <>
            {messages.messages}
            {
              props.environments.length === 0 &&
              <h4>{t("No environments created")}</h4>
            }
            {
              props.environments.map((environment, i) =>
                <React.Fragment key={environment.label}>
                  <div className="row">
                    <CreatorPanel
                      id={`environment${environment.label}`}
                      title={environment.name}
                      creatingText="Edit"
                      panelLevel="3"
                      disableEditing={!hasEditingPermissions}
                      disableOperations={isLoading}
                      onSave={({ item, closeDialog }) =>
                        onAction(mapUpdateEnvironmentRequest(item, props.projectId), "update", props.projectId)
                          .then((projectWithUpdatedEnvironment) => {
                            props.onChange(projectWithUpdatedEnvironment)
                            closeDialog();
                            showSuccessToastr(t("Environment updated successfully"));
                          })
                          .catch((error) => {
                            showErrorToastr(error, {autoHide: false});
                          })}
                      onOpen={({ setItem }) => setItem(environment)}
                      onCancel={() => cancelAction()}
                      onDelete={({ item, closeDialog }) => {
                        return onAction(item, "delete", props.projectId)
                          .then((projectWithDeleteddEnvironment) => {
                            closeDialog()
                              .then(() => {
                                props.onChange(projectWithDeleteddEnvironment);
                              });
                            showSuccessToastr(t("Environment {0} deleted successfully", environment.label));
                          })
                          .catch((error) => {
                            showErrorToastr(error, {autoHide: false});
                          })
                      }}
                      renderCreationContent={({ open, item, setItem }) => {
                        if (!open) {
                          return null;
                        }

                        if (isLoading) {
                          return (
                            <Loading text='Editing the environment..'/>
                          )
                        }

                        return (
                          <EnvironmentForm
                            environment={{...item}}
                            environments={props.environments}
                            onChange={(item) => setItem(item)}
                            editing
                          />
                        )
                      }}
                      renderContent={() => <EnvironmentView
                        environment={environment}
                        historyEntries={props.historyEntries}
                      />}/>
                  </div>
                  {
                    props.environments.length - 1 !== i &&
                    <Promote
                      projectId={props.projectId}
                      environmentPromote={environment}
                      environmentTarget={props.environments[i + 1]}
                      environmentNextTarget={props.environments[i + 2]}
                      historyEntries={props.historyEntries}
                      versionToPromote={environment.version}
                      onChange={props.onChange}
                    />
                  }
                </React.Fragment>
              )
            }
          </>
        </div>
      }
    />
  )
}

export default EnvironmentLifecycle;
