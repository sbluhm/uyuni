/* eslint-disable */
'use strict';

const React = require("react");
const ReactDOM = require("react-dom");
const { InnerPanel } = require('components/panels/InnerPanel');
const Button = require("components/buttons").Button;
const {Toggler} = require("components/toggler");
const ModalButton = require("components/dialog/ModalButton").ModalButton;
const DeleteDialog = require("components/dialog/DeleteDialog").DeleteDialog;
const {Column} = require("components/table/Column");
const {Table} = require("components/table/Table");

// todo extract to utils
const targetTypeToString = (targetType) => {
    switch(targetType) {
        case "MINION":
            return "Minion";
        case "GROUP":
            return "Group";
        case "ORG":
            return "Organization";
    }
    return null;
};

class RecurringStatesList extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            itemsToDelete: []
        };
    }

    selectToDelete(item) {
        this.setState({
            itemToDelete: item
        });
    }

    render() {
        const createButton = [
            <div className="btn-group pull-right">
                <Button
                    className="btn-default"
                    icon="fa-plus"
                    text={t("Create")}
                    title="Schedule a new Recurring States Action"
                    handler={() => this.props.onActionChanged("create")}
                />
            </div>
        ];

        return (
            <div>
                <InnerPanel title={t("Recurring States")} icon="spacewalk-icon-salt" buttons={this.props.disableCreate ? null : createButton}>
                    <div className="panel panel-default">
                        <div className="panel-heading">
                            <div>
                                <h3>Schedules</h3>
                            </div>
                        </div>
                        <div>
                            <Table
                                data={this.props.data}
                                identifier={action => action.recurringActionId}
                                /* Using 0 to hide table header/footer */
                                initialItemsPerPage={this.props.disableCreate ? userPrefPageSize : 0}
                                emptyText={t("No schedules created." + (this.props.disableCreate ? "" : " Use Create to add a schedule."))}
                            >
                                <Column
                                    columnKey="active"
                                    header={t('Active')}
                                    cell={(row) =>
                                        <Toggler
                                            value={row.active}
                                            className="btn"
                                            handler={() => this.props.onToggleActive(row)}
                                        />
                                    }
                                />
                                <Column
                                    columnClass="text-center"
                                    headerClass="text-center"
                                    columnKey="scheduleName"
                                    header={t('Schedule Name')}
                                    cell={(row) => row.scheduleName}
                                />
                                <Column
                                    columnClass="text-center"
                                    headerClass="text-center"
                                    columnKey="frequency"
                                    header={t('Frequency')}
                                    cell={(row) => row.cron}
                                />
                                <Column
                                    columnClass="text-center"
                                    headerClass="text-center"
                                    columnKey="targetType"
                                    header={t('Target Type')}
                                    cell={(row) => targetTypeToString(row.targetType)}
                                />
                                <Column
                                    columnClass="text-right"
                                    headerClass="text-right"
                                    header={t('Actions')}
                                    cell={(row) =>
                                        <div className="btn-group">
                                            <Button
                                                className="btn-default btn-sm"
                                                title={t("Details")}
                                                icon="fa-list"
                                                handler={() => {this.props.onSelect(row)}}
                                            />
                                            <Button
                                                className="btn-default btn-sm"
                                                title={t("Edit")}
                                                icon="fa-edit"
                                                handler={() => {this.props.onEdit(row)}}
                                            />
                                            <ModalButton
                                                className="btn-default btn-sm"
                                                title={t("Delete")}
                                                icon="fa-trash"
                                                target="delete-modal"
                                                item={row}
                                                onClick={i => this.selectToDelete(i)}
                                            />
                                        </div>
                                    }
                                />
                            </Table>
                            <DeleteDialog id="delete-modal"
                                          title={t("Delete Recurring State Schedule")}
                                          content={t("Are you sure you want to delete the selected item?")}
                                          onConfirm={() => this.props.onDelete(this.state.itemToDelete)}
                                          onClosePopUp={() => this.selectToDelete(null)}
                            />
                        </div>
                    </div>
                </InnerPanel>
            </div>
        );
    }
}

module.exports = {
    RecurringStatesList: RecurringStatesList
};
